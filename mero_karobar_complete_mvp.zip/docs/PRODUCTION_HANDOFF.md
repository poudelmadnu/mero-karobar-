# Production handoff checklist

## Authentication
- Firebase Authentication: Google provider and Phone provider.
- Phone OTP requires supported country configuration, billing/quotas and anti-abuse verification.
- Provide sign-out and account deletion.
- Never store OTP codes or passwords in app preferences.

## Data model recommendation
`users/{uid}/records/{recordId}`
Fields: type, title, category, amount, currency, transactionDate, note, receiptStoragePath, createdAt, updatedAt.
`users/{uid}/memos/{memoId}`
Fields: title, body, dueAt, isCompleted, createdAt.
Use server timestamps and per-user Firestore security rules.

## Financial correctness
- Use decimal-safe integer minor units (paisa) or a decimal type in production.
- Define whether balance includes opening balance, cash, bank and wallet accounts.
- Keep settlement records linked to the original receivable/payable record.
- Add edit/delete audit history and CSV/PDF export.
- Test month/year boundaries, refunds, partial payments and duplicate sync.

## Security and privacy
- Require authentication before cloud access.
- Firestore rules must deny access by default.
- Validate amounts and ownership on the server.
- Avoid public receipt URLs; use authenticated storage access.
- Provide privacy policy, data export and account deletion.
