# MERO KAROBAR — Flutter MVP source project

This project contains an expanded offline-first MVP source code for an Android ledger app.

## Included in this build
- Dashboard: cash balance, income, expenses, receivable and payable totals
- Add income and expense entries
- Add receivable and payable records
- Record payment received / payment made
- Attach a bill image from the gallery to income/expense entries
- View attached receipt images from the transaction list
- Monthly breakdown and current-calendar-year report
- Calculator with arithmetic expression evaluation
- Notes / reminder list (notes are saved; scheduled push/local notifications are not yet wired)
- Nepali/English labels toggle on the dashboard and common labels
- Local persistence on the device using SharedPreferences

## Important limitations (read before relying on it)
This is a source-code MVP, not a fully deployed production app and not a signed APK.
- Data is currently stored locally on the device. Firebase cloud sync is NOT configured.
- Google Sign-In and phone OTP are NOT connected.
- Photo attachments store a local device file path; they are not backed up to cloud.
- Bikram Sambat date conversion is not implemented; dates in reports currently use Gregorian calendar.
- Reminder notes are saved, but scheduled notifications are not yet implemented.
- This starter has not been compiled or tested on a physical Android device in this environment.
- No app can be published to Google Play from this project alone; Play Console setup, policy declarations, signing, testing and review are required.

Do not use this MVP as the only copy of important financial records. Export/backup and security controls must be completed before real financial use.

## Run locally
1. Install Flutter SDK and Android Studio.
2. Extract this ZIP.
3. Open a terminal in the project directory.
4. Run `flutter pub get`.
5. Connect an Android device with USB debugging enabled or start an emulator.
6. Run `flutter run`.

## Firebase production integration
To add Google login, phone OTP, Firestore cloud sync and cloud receipt storage:
1. Create a Firebase project.
2. Register Android application using the final Android application ID.
3. Install FlutterFire CLI and run `flutterfire configure`.
4. Add and configure `firebase_core`, `firebase_auth`, `cloud_firestore`, `firebase_storage`, and `google_sign_in`.
5. Enable Phone and Google providers in Firebase Authentication.
6. Add Firestore security rules so each user can read/write only their own records.
7. Upload receipt images to Firebase Storage under a per-user path and store the resulting download URL in Firestore.
8. Implement offline sync conflict handling, account deletion, data export and privacy controls.
9. Test OTP delivery, sign-in, sync, restore, access control and offline behavior.

## Play Store release checklist
- Choose final application ID and app signing.
- Create a signed Android App Bundle (AAB).
- Prepare app icon, screenshots, feature graphic and store listing.
- Publish a privacy policy and complete Data Safety declarations accurately.
- Test on supported Android versions and different screen sizes.
- Complete Play Console testing and review requirements.
