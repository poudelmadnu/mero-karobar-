import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:math_expressions/math_expressions.dart';

void main() => runApp(const MeroKarobarApp());

class Record {
  final String id, title, category, type, note, imagePath;
  final double amount;
  final DateTime date;
  Record({required this.id, required this.title, required this.category,
    required this.type, required this.amount, required this.date,
    this.note = '', this.imagePath = ''});
  Map<String,dynamic> toJson()=>{'id':id,'title':title,'category':category,'type':type,
    'amount':amount,'date':date.toIso8601String(),'note':note,'imagePath':imagePath};
  factory Record.fromJson(Map<String,dynamic> j)=>Record(
    id:j['id'],title:j['title'],category:j['category'],type:j['type'],
    amount:(j['amount'] as num).toDouble(),date:DateTime.parse(j['date']),
    note:j['note']??'',imagePath:j['imagePath']??'');
}
class Memo {
  final String id, title, body;
  final DateTime date;
  Memo(this.id,this.title,this.body,this.date);
  Map<String,dynamic> toJson()=>{'id':id,'title':title,'body':body,'date':date.toIso8601String()};
  factory Memo.fromJson(Map<String,dynamic> j)=>Memo(j['id'],j['title'],j['body'],DateTime.parse(j['date']));
}

class MeroKarobarApp extends StatelessWidget {
  const MeroKarobarApp({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(
    title:'मेरो कारोबार',debugShowCheckedModeBanner:false,
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF16834A)),
      useMaterial3:true,scaffoldBackgroundColor:const Color(0xFFF5F8F5)),
    home:const LedgerHome());
}

class LedgerHome extends StatefulWidget {
  const LedgerHome({super.key});
  @override State<LedgerHome> createState()=>_LedgerHomeState();
}
class _LedgerHomeState extends State<LedgerHome> {
  List<Record> records=[];
  List<Memo> memos=[];
  int tab=0;
  bool english=false;
  bool busy=true;
  final picker=ImagePicker();
  final fmt=NumberFormat('#,##0.00','en_US');
  String tr(String n,String e)=>english?e:n;
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    final r=p.getString('records_v2'), m=p.getString('memos_v2');
    if(r!=null) records=(jsonDecode(r) as List).map((x)=>Record.fromJson(Map<String,dynamic>.from(x))).toList();
    if(m!=null) memos=(jsonDecode(m) as List).map((x)=>Memo.fromJson(Map<String,dynamic>.from(x))).toList();
    if(mounted)setState(()=>busy=false);
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setString('records_v2',jsonEncode(records.map((e)=>e.toJson()).toList()));
    await p.setString('memos_v2',jsonEncode(memos.map((e)=>e.toJson()).toList()));
  }
  double total(String type)=>records.where((r)=>r.type==type).fold(0,(s,r)=>s+r.amount);
  double get income=>total('income');
  double get expense=>total('expense');
  double get receivable=>total('receivable')-total('received');
  double get payable=>total('payable')-total('paid');
  double get cashBalance=>income-expense+total('received')-total('paid');

  Future<void> addRecord(String type) async {
    final title=TextEditingController(),amount=TextEditingController(),category=TextEditingController(),note=TextEditingController();
    String imagePath='';
    final titleMap={'income':tr('आम्दानी थप्नुहोस्','Add income'),'expense':tr('खर्च थप्नुहोस्','Add expense'),
      'receivable':tr('पाउनुपर्ने रकम','Money to receive'),'payable':tr('दिनुपर्ने रकम','Money to pay'),
      'received':tr('रकम प्राप्त भयो','Payment received'),'paid':tr('रकम तिरियो','Payment made')};
    await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(
      title:Text(titleMap[type]??'New record'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:title,decoration:InputDecoration(labelText:tr('नाम / विवरण','Name / description'))),
        TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:tr('रकम (रु.)','Amount (NPR)'))),
        TextField(controller:category,decoration:InputDecoration(labelText:tr('शीर्षक / व्यक्ति','Category / person'))),
        TextField(controller:note,decoration:InputDecoration(labelText:tr('नोट','Note'))),
        if(type=='expense'||type=='income') ...[
          const SizedBox(height:8),
          OutlinedButton.icon(onPressed:()async{
            final x=await picker.pickImage(source:ImageSource.gallery,imageQuality:80);
            if(x!=null)setD(()=>imagePath=x.path);
          },icon:const Icon(Icons.photo),label:Text(imagePath.isEmpty?tr('बिलको फोटो छान्नुहोस्','Attach bill photo'):tr('फोटो जोडियो','Photo attached'))),
          if(imagePath.isNotEmpty)Text(imagePath.split('/').last,style:const TextStyle(fontSize:11)),
        ]
      ])),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(ctx),child:Text(tr('रद्द','Cancel'))),
        FilledButton(onPressed:()async{
          final a=double.tryParse(amount.text.trim());
          if(title.text.trim().isEmpty||a==null||a<=0)return;
          setState(()=>records.insert(0,Record(id:DateTime.now().microsecondsSinceEpoch.toString(),
            title:title.text.trim(),category:category.text.trim(),type:type,amount:a,date:DateTime.now(),
            note:note.text.trim(),imagePath:imagePath)));
          await save();if(ctx.mounted)Navigator.pop(ctx);
        },child:Text(tr('सेभ','Save')))
      ],
    )));
  }

  Future<void> addMemo() async {
    final title=TextEditingController(),body=TextEditingController();
    await showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(tr('नयाँ नोट / रिमाइन्डर','New note / reminder')),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:title,decoration:InputDecoration(labelText:tr('शीर्षक','Title'))),
        TextField(controller:body,maxLines:3,decoration:InputDecoration(labelText:tr('विवरण','Details'))),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:Text(tr('रद्द','Cancel'))),
        FilledButton(onPressed:()async{if(title.text.trim().isEmpty)return;
          setState(()=>memos.insert(0,Memo(DateTime.now().microsecondsSinceEpoch.toString(),title.text,body.text,DateTime.now())));
          await save();if(ctx.mounted)Navigator.pop(ctx);},child:Text(tr('सेभ','Save')))]));
  }

  Widget tile(Record r)=>Card(child:ListTile(
    leading:CircleAvatar(backgroundColor:r.type=='income'||r.type=='received'?const Color(0xFFE1F3E7):const Color(0xFFFFE9E6),
      child:Icon(r.type=='income'||r.type=='received'?Icons.south_west:Icons.north_east,
        color:r.type=='income'||r.type=='received'?Colors.green:Colors.red)),
    title:Text(r.title),subtitle:Text('${r.category} • ${DateFormat('yyyy-MM-dd').format(r.date)}${r.note.isEmpty?'':'\\n${r.note}'}'),
    isThreeLine:r.note.isNotEmpty,
    trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[
      Text('रु. ${fmt.format(r.amount)}',style:const TextStyle(fontWeight:FontWeight.bold)),
      if(r.imagePath.isNotEmpty)const Icon(Icons.attach_file,size:14),
    ]),
    onTap:r.imagePath.isEmpty?null:()=>showDialog(context:context,builder:(_)=>Dialog(child:Image.file(File(r.imagePath),fit:BoxFit.contain))),
  ));

  Widget metric(String label,double value,Color c,IconData i)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(13),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(i,color:c),const SizedBox(height:7),Text(label,style:const TextStyle(fontSize:12,color:Colors.black54)),
      const SizedBox(height:4),FittedBox(child:Text('रु. ${fmt.format(value)}',style:TextStyle(fontWeight:FontWeight.bold,color:c,fontSize:17)))
    ]))));
  Widget dashboard()=>ListView(padding:const EdgeInsets.all(15),children:[
    Row(children:[const CircleAvatar(backgroundColor:Color(0xFFE2F3E8),child:Icon(Icons.account_balance_wallet,color:Color(0xFF16834A))),
      const SizedBox(width:10),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('MERO KAROBAR',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1)),
        Text('Personal & Small Business Ledger',style:TextStyle(fontSize:11,color:Colors.black54))])),
      IconButton(onPressed:()=>setState(()=>english=!english),icon:const Icon(Icons.language),tooltip:'नेपाली / English')]),
    const SizedBox(height:12),
    Card(color:const Color(0xFF16834A),child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(tr('जम्मा ब्यालेन्स','Total balance'),style:const TextStyle(color:Colors.white70)),
      const SizedBox(height:6),Text('रु. ${fmt.format(cashBalance)}',style:const TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.bold)),
      Text(tr('आम्दानी + प्राप्त रकम − खर्च − तिरेको रकम','Income + received − expenses − paid'),style:const TextStyle(color:Colors.white70,fontSize:11))
    ]))),
    Row(children:[metric(tr('आम्दानी','Income'),income,Colors.green,Icons.trending_up),metric(tr('खर्च','Expenses'),expense,Colors.red,Icons.trending_down)]),
    Row(children:[metric(tr('पाउनुपर्ने','Receivable'),receivable,Colors.blue,Icons.call_received),metric(tr('दिनुपर्ने','Payable'),payable,Colors.deepOrange,Icons.call_made)]),
    const SizedBox(height:8),
    Wrap(spacing:8,runSpacing:8,children:[
      FilledButton.icon(onPressed:()=>addRecord('income'),icon:const Icon(Icons.add),label:Text(tr('आम्दानी','Income'))),
      FilledButton.tonalIcon(onPressed:()=>addRecord('expense'),icon:const Icon(Icons.remove),label:Text(tr('खर्च','Expense'))),
      OutlinedButton.icon(onPressed:()=>addRecord('receivable'),icon:const Icon(Icons.call_received),label:Text(tr('पाउनुपर्ने','Receivable'))),
      OutlinedButton.icon(onPressed:()=>addRecord('payable'),icon:const Icon(Icons.call_made),label:Text(tr('दिनुपर्ने','Payable'))),
    ]),
    const SizedBox(height:14),Text(tr('हालैका कारोबार','Recent activity'),style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
    if(records.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Center(child:Text('कारोबार थप्न + बटन प्रयोग गर्नुहोस्।')))
    else ...records.take(6).map(tile),
  ]);

  Widget accountList(String type,String title,String settleType)=>ListView(padding:const EdgeInsets.all(15),children:[
    Text(title,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),
    FilledButton.icon(onPressed:()=>addRecord(type),icon:const Icon(Icons.add),label:Text(tr('नयाँ रेकर्ड','Add record'))),
    const SizedBox(height:8),
    ...records.where((r)=>r.type==type).map((r)=>Card(child:ListTile(
      title:Text(r.category.isEmpty?r.title:r.category),subtitle:Text(r.title),
      trailing:Wrap(mainAxisSize:MainAxisSize.min,children:[
        Text('रु. ${fmt.format(r.amount)}'),
        IconButton(tooltip:tr('भुक्तानी रेकर्ड','Record settlement'),icon:const Icon(Icons.check_circle_outline),
          onPressed:()=>addRecord(settleType)),
      ]))))
  ]);

  Widget reports(){
    final year=DateTime.now().year;
    final yr=records.where((r)=>r.date.year==year).toList();
    double sum(List<Record> xs,String type)=>xs.where((r)=>r.type==type).fold(0,(s,r)=>s+r.amount);
    return ListView(padding:const EdgeInsets.all(15),children:[
      Text(tr('वार्षिक तथा मासिक रिपोर्ट','Yearly & monthly reports'),style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
        Text('$year ${tr('को कुल हिसाब','summary')}',style:const TextStyle(fontWeight:FontWeight.bold)),
        reportLine(tr('कुल आम्दानी','Total income'),sum(yr,'income'),Colors.green),
        reportLine(tr('कुल खर्च','Total expenses'),sum(yr,'expense'),Colors.red),
        reportLine(tr('बाँकी','Net'),sum(yr,'income')-sum(yr,'expense'),Colors.blue),
      ]))),
      const SizedBox(height:8),Text(tr('महिनाअनुसार कारोबार','Monthly breakdown'),style:const TextStyle(fontWeight:FontWeight.bold)),
      ...List.generate(12,(i){final m=i+1;final xs=yr.where((r)=>r.date.month==m).toList();
        final inc=sum(xs,'income'),exp=sum(xs,'expense');
        return Card(child:ListTile(title:Text(DateFormat('MMMM').format(DateTime(year,m))),
          subtitle:Text('${tr('आम्दानी','Income')}: रु. ${fmt.format(inc)}  |  ${tr('खर्च','Expense')}: रु. ${fmt.format(exp)}'),
          trailing:Text('रु. ${fmt.format(inc-exp)}',style:const TextStyle(fontWeight:FontWeight.bold))));
      })
    ]);
  }
  Widget reportLine(String l,double v,Color c)=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Row(children:[
    Expanded(child:Text(l)),Text('रु. ${fmt.format(v)}',style:TextStyle(fontWeight:FontWeight.bold,color:c))]));

  @override Widget build(BuildContext context){
    if(busy)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final pages=[dashboard(),accountList('receivable',tr('पाउनुपर्ने खाता','Receivables'),'received'),
      accountList('payable',tr('दिनुपर्ने खाता','Payables'),'paid'),reports(),const CalculatorScreen(),notesScreen()];
    final labels=[tr('होम','Home'),tr('पाउनुपर्ने','Receive'),tr('दिनुपर्ने','Pay'),tr('रिपोर्ट','Reports'),tr('क्याल्कुलेटर','Calculator'),tr('नोट','Notes')];
    final icons=[Icons.home,Icons.call_received,Icons.call_made,Icons.bar_chart,Icons.calculate,Icons.notifications_active];
    return Scaffold(appBar:AppBar(title:Text(labels[tab]),actions:[if(tab==5)IconButton(onPressed:addMemo,icon:const Icon(Icons.add))]),
      body:pages[tab],
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations:List.generate(6,(i)=>NavigationDestination(icon:Icon(icons[i]),label:labels[i]))));
  }

  Widget notesScreen()=>ListView(padding:const EdgeInsets.all(15),children:[
    FilledButton.icon(onPressed:addMemo,icon:const Icon(Icons.add),label:Text(tr('नयाँ नोट / रिमाइन्डर','New note / reminder'))),
    if(memos.isEmpty)const Padding(padding:EdgeInsets.all(24),child:Center(child:Text('अहिलेसम्म नोट छैन।'))),
    ...memos.map((m)=>Card(child:ListTile(leading:const Icon(Icons.notifications_none),title:Text(m.title),
      subtitle:Text('${m.body}\\n${DateFormat('yyyy-MM-dd').format(m.date)}'),isThreeLine:true,
      trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{setState(()=>memos.removeWhere((x)=>x.id==m.id));await save();}))))
  ]);
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});
  @override State<CalculatorScreen> createState()=>_CalculatorScreenState();
}
class _CalculatorScreenState extends State<CalculatorScreen>{
  String expr='',answer='0';
  void key(String k){
    setState((){
      if(k=='AC'){expr='';answer='0';return;}
      if(k=='DEL'){if(expr.isNotEmpty)expr=expr.substring(0,expr.length-1);return;}
      if(k=='='){
        try{
          final normalized=expr.replaceAll('×','*').replaceAll('÷','/');
          final p=Parser();final e=p.parse(normalized);
          final v=e.evaluate(EvaluationType.REAL,ContextModel());
          answer=NumberFormat('#,##0.####').format(v);
        }catch(_){answer='त्रुटि / Error';}
        return;
      }
      expr+=k;
    });
  }
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(16),child:Column(children:[
    Card(child:Container(width:double.infinity,padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
      Text(expr.isEmpty?'0':expr,style:const TextStyle(fontSize:24)),const SizedBox(height:12),
      Text(answer,style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold,color:Color(0xFF16834A)))
    ]))),
    const SizedBox(height:12),
    Expanded(child:GridView.count(crossAxisCount:4,mainAxisSpacing:8,crossAxisSpacing:8,children:[
      for(final k in ['7','8','9','÷','4','5','6','×','1','2','3','−','AC','0','.','+','(',')','DEL','='])
        FilledButton.tonal(onPressed:()=>key(k=='−'?'-':k),child:Text(k,style:const TextStyle(fontSize:20)))
    ]))
  ]));
}
